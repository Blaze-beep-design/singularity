package com.singularity.game;

import com.badlogic.gdx.graphics.VertexAttributes.Usage;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;

public class Attacks {
    static final float CYCLE = 13f;
    static final float WELL_R = 50f;
    static final float WELL_PULL = 18f;
    static final float METEOR_SPEED = 90f;
    static final float RING_SPEED = 45f;
    static final float GAP_HALF = 24f;
    static final float LIMIT = 147f;
    static final int METEORS = 40;
    static final int RINGS = 4;
    static final int SEGS = 60;
    static final float[] RING_TIMES = {1.5f, 4f, 6.5f, 9f};

    public float pullX;
    public float pullZ;
    public final Array<ModelInstance> visible = new Array<ModelInstance>();

    private final Array<Model> models = new Array<Model>();
    private final ModelInstance wellDisc, wellCore;
    private final ModelInstance[] meteor = new ModelInstance[METEORS];
    private final ModelInstance[] marker = new ModelInstance[METEORS];
    private final float[] mx = new float[METEORS];
    private final float[] my = new float[METEORS];
    private final float[] mz = new float[METEORS];
    private final boolean[] mAlive = new boolean[METEORS];
    private final ModelInstance[][] seg = new ModelInstance[RINGS][SEGS];
    private final float[] ringR = new float[RINGS];
    private final float[] ringGap = new float[RINGS];
    private final boolean[] ringAlive = new boolean[RINGS];
    private final boolean[] ringSpawned = new boolean[RINGS];

    private boolean running;
    private float t;
    private float spawnTimer;

    private Material glass(float r, float g, float b, float a) {
        return new Material(ColorAttribute.createDiffuse(r, g, b, 1f), new BlendingAttribute(a));
    }

    private Model keep(Model m) {
        models.add(m);
        return m;
    }

    public Attacks() {
        ModelBuilder mb = new ModelBuilder();
        long attr = Usage.Position | Usage.Normal;
        wellDisc = new ModelInstance(keep(mb.createCylinder(WELL_R * 2f, 0.2f, WELL_R * 2f, 40,
                glass(0.35f, 0.1f, 0.7f, 0.3f), attr)));
        wellCore = new ModelInstance(keep(mb.createCylinder(10f, 0.3f, 10f, 24,
                glass(0.9f, 0.05f, 0.2f, 0.8f), attr)));
        Model meteorModel = keep(mb.createSphere(5f, 5f, 5f, 12, 8,
                new Material(ColorAttribute.createDiffuse(1f, 0.45f, 0.2f, 1f)), attr));
        Model markerModel = keep(mb.createCylinder(7f, 0.1f, 7f, 20,
                glass(1f, 0.2f, 0.2f, 0.4f), attr));
        for (int i = 0; i < METEORS; i++) {
            meteor[i] = new ModelInstance(meteorModel);
            marker[i] = new ModelInstance(markerModel);
        }
        Model ringModel = keep(mb.createBox(1f, 1f, 1f, glass(0.9f, 0.4f, 1f, 0.85f), attr));
        for (int k = 0; k < RINGS; k++) {
            for (int s = 0; s < SEGS; s++) {
                seg[k][s] = new ModelInstance(ringModel);
            }
        }
    }

    private void clearAll() {
        for (int i = 0; i < METEORS; i++) {
            mAlive[i] = false;
        }
        for (int k = 0; k < RINGS; k++) {
            ringAlive[k] = false;
            ringSpawned[k] = false;
        }
    }

    public void start() {
        running = true;
        t = -3f;
        spawnTimer = 0f;
        clearAll();
        visible.clear();
        pullX = 0f;
        pullZ = 0f;
    }

    public void stop() {
        running = false;
    }

    private static float angDiff(float a, float b) {
        float d = Math.abs(a - b) % 360f;
        return d > 180f ? 360f - d : d;
    }

    private void spawnMeteor(float px, float pz) {
        for (int i = 0; i < METEORS; i++) {
            if (!mAlive[i]) {
                boolean near = MathUtils.randomBoolean();
                float x = near ? px + MathUtils.random(-16f, 16f) : MathUtils.random(-LIMIT, LIMIT);
                float z = near ? pz + MathUtils.random(-16f, 16f) : MathUtils.random(-LIMIT, LIMIT);
                mx[i] = MathUtils.clamp(x, -LIMIT, LIMIT);
                mz[i] = MathUtils.clamp(z, -LIMIT, LIMIT);
                my[i] = 120f;
                mAlive[i] = true;
                return;
            }
        }
    }

    private void spawnRing() {
        for (int k = 0; k < RINGS; k++) {
            if (!ringAlive[k]) {
                ringAlive[k] = true;
                ringR[k] = 6f;
                ringGap[k] = MathUtils.random(0f, 360f);
                return;
            }
        }
    }

    public boolean update(float dt, float px, float py, float pz) {
        pullX = 0f;
        pullZ = 0f;
        if (!running) {
            return false;
        }
        visible.clear();
        boolean hit = false;
        t += dt;
        if (t >= CYCLE) {
            t -= CYCLE;
            for (int k = 0; k < RINGS; k++) {
                ringSpawned[k] = false;
            }
        }
        if (t >= 0f) {
            if (t < 6f) {
                float dx = -px;
                float dz = -pz;
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                if (d < WELL_R && d > 0.01f) {
                    pullX = dx / d * WELL_PULL * dt;
                    pullZ = dz / d * WELL_PULL * dt;
                }
                if (d < 5f && py < 3f) {
                    hit = true;
                }
                wellDisc.transform.setToTranslation(0f, 0.12f, 0f);
                wellCore.transform.setToTranslation(0f, 0.2f, 0f);
                visible.add(wellDisc);
                visible.add(wellCore);
            }
            if (t < 10f) {
                spawnTimer -= dt;
                if (spawnTimer <= 0f) {
                    spawnTimer += 0.25f;
                    spawnMeteor(px, pz);
                }
            }
            for (int k = 0; k < RINGS; k++) {
                if (!ringSpawned[k] && t >= RING_TIMES[k]) {
                    ringSpawned[k] = true;
                    spawnRing();
                }
            }
        }

        for (int i = 0; i < METEORS; i++) {
            if (!mAlive[i]) {
                continue;
            }
            my[i] -= METEOR_SPEED * dt;
            if (my[i] <= 2.5f) {
                mAlive[i] = false;
                continue;
            }
            meteor[i].transform.setToTranslation(mx[i], my[i], mz[i]);
            marker[i].transform.setToTranslation(mx[i], 0.1f, mz[i]);
            visible.add(marker[i]);
            visible.add(meteor[i]);
            float dx = px - mx[i];
            float dz = pz - mz[i];
            if (dx * dx + dz * dz < 3.4f * 3.4f && my[i] > py - 1f && my[i] < py + 6.5f) {
                hit = true;
            }
        }

        float pAng = MathUtils.atan2(pz, px) * MathUtils.radiansToDegrees;
        if (pAng < 0f) {
            pAng += 360f;
        }
        float pDist = (float) Math.sqrt(px * px + pz * pz);
        for (int k = 0; k < RINGS; k++) {
            if (!ringAlive[k]) {
                continue;
            }
            ringR[k] += RING_SPEED * dt;
            float r = ringR[k];
            if (r > 230f) {
                ringAlive[k] = false;
                continue;
            }
            float segW = (float) (2.0 * Math.PI * r / SEGS) * 1.03f;
            for (int s = 0; s < SEGS; s++) {
                float a = s * 360f / SEGS;
                if (angDiff(a, ringGap[k]) < GAP_HALF) {
                    continue;
                }
                seg[k][s].transform.setToTranslation(r * MathUtils.cosDeg(a), 2f, r * MathUtils.sinDeg(a))
                        .rotate(Vector3.Y, -a).scale(1.4f, 4f, segW);
                visible.add(seg[k][s]);
            }
            if (Math.abs(pDist - r) < 2.4f && py < 4.2f && angDiff(pAng, ringGap[k]) >= GAP_HALF) {
                hit = true;
            }
        }
        return hit;
    }

    public void dispose() {
        for (Model m : models) {
            m.dispose();
        }
    }
}
