package com.singularity.game;

import com.badlogic.gdx.graphics.VertexAttributes.Usage;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Quaternion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;

public class Attacks {
    static final float HALF = SingularityGame.HALF;
    static final String[] NAMES = {"FALL", "STRETCH", "DRIFT", "BINARY", "FLIP"};
    static final float[] GDUR = {13f, 12f, 13f, 12f, 12f};
    static final float PAUSE = 2.5f;
    static final float WELL_R = 50f;
    static final float WELL_PULL = 18f;
    static final float METEOR_SPEED = 90f;
    static final float RING_SPEED = 45f;
    static final float GAP_HALF = 24f;
    static final float SPAG_PULL = 20f;
    static final float LIMIT = HALF - 3f;
    static final int METEORS = 40;
    static final int RINGS = 10;
    static final int SEGS = 48;
    static final int COMETS = 12;
    static final int HAWKS = 70;
    static final int WAVES = 3;
    static final int HIST = 120;
    static final float[] RING_TIMES = {1.5f, 4f, 6.5f, 9f};

    public float pullX;
    public float pullZ;
    public float speedMul = 1f;
    public float gravMul = 1f;
    public float flipTint;
    public final Array<ModelInstance> visible = new Array<ModelInstance>();

    private final Array<Model> models = new Array<Model>();
    private final Vector3 dir = new Vector3();
    private final Vector3 mid = new Vector3();
    private final Vector3 va = new Vector3();
    private final Vector3 vb = new Vector3();
    private final Quaternion q = new Quaternion();

    private final ModelInstance wellDisc, wellCore, rzDisc, hotDisc, spagBeam, lanceInst;
    private final ModelInstance[] meteor = new ModelInstance[METEORS];
    private final ModelInstance[] marker = new ModelInstance[METEORS];
    private final float[] mx = new float[METEORS];
    private final float[] my = new float[METEORS];
    private final float[] mz = new float[METEORS];
    private final boolean[] mAlive = new boolean[METEORS];
    private final ModelInstance[][] seg = new ModelInstance[RINGS][SEGS];
    private final float[] ringR = new float[RINGS];
    private final float[] ringMax = new float[RINGS];
    private final float[] ringSp = new float[RINGS];
    private final float[] ringGap = new float[RINGS];
    private final float[] ringGH = new float[RINGS];
    private final float[] ringCX = new float[RINGS];
    private final float[] ringCZ = new float[RINGS];
    private final boolean[] ringAlive = new boolean[RINGS];
    private final ModelInstance[] hawk = new ModelInstance[HAWKS];
    private final float[] hx = new float[HAWKS];
    private final float[] hy = new float[HAWKS];
    private final float[] hz = new float[HAWKS];
    private final float[] hvx = new float[HAWKS];
    private final float[] hvy = new float[HAWKS];
    private final float[] hvz = new float[HAWKS];
    private final float[] hLife = new float[HAWKS];
    private final ModelInstance[] comet = new ModelInstance[COMETS];
    private final float[] cx = new float[COMETS];
    private final float[] cz = new float[COMETS];
    private final float[] cvx = new float[COMETS];
    private final float[] cvz = new float[COMETS];
    private final boolean[] cAlive = new boolean[COMETS];
    private final ModelInstance[] wave = new ModelInstance[WAVES];
    private final float[] wc = new float[WAVES];
    private final float[] wDir = new float[WAVES];
    private final int[] wAxis = new int[WAVES];
    private final boolean[] wAlive = new boolean[WAVES];
    private final ModelInstance[] voidInst = new ModelInstance[2];
    private final float[] hxh = new float[HIST];
    private final float[] hzh = new float[HIST];
    private final float[] hth = new float[HIST];
    private final boolean[] fired = new boolean[16];
    private final float[] anchorCd = new float[8];

    private float[] axs;
    private float[] azs;
    private boolean[] aliveRef;
    private int histHead, histCount;
    private float now, lagX, lagZ;
    private boolean running;
    private int group;
    private int lockGroup = -1;
    private float gt;
    private float rainTimer, hawkTimer, cometTimer;
    private boolean rzInit;
    private float rzX, rzZ;
    private boolean voidOn;
    private float voidT, voidA0;
    private float lanceT;
    private final Vector3 lanceA = new Vector3();
    private final Vector3 lanceB = new Vector3();
    private boolean hit;

    private Material glass(float r, float g, float b, float a) {
        return new Material(ColorAttribute.createDiffuse(r, g, b, 1f), new BlendingAttribute(a));
    }

    private Material solid(float r, float g, float b) {
        return new Material(ColorAttribute.createDiffuse(r, g, b, 1f));
    }

    private Model keep(Model m) {
        models.add(m);
        return m;
    }

    public Attacks() {
        ModelBuilder mb = new ModelBuilder();
        long attr = Usage.Position | Usage.Normal;
        wellDisc = new ModelInstance(keep(mb.createCylinder(WELL_R * 2f, 0.2f, WELL_R * 2f, 40,
                glass(0.35f, 0.1f, 0.7f, 0.3f), attr)));
        wellCore = new ModelInstance(keep(mb.createCylinder(10f, 0.3f, 10f, 24,
                glass(0.9f, 0.05f, 0.2f, 0.8f), attr)));
        rzDisc = new ModelInstance(keep(mb.createCylinder(28f, 0.2f, 28f, 32,
                glass(1f, 0.15f, 0.1f, 0.3f), attr)));
        hotDisc = new ModelInstance(keep(mb.createCylinder(16f, 0.2f, 16f, 28,
                glass(1f, 0.2f, 0.2f, 0.35f), attr)));
        spagBeam = new ModelInstance(keep(mb.createBox(1f, 1f, 1f, glass(0.5f, 0.9f, 1f, 0.8f), attr)));
        lanceInst = new ModelInstance(keep(mb.createBox(1f, 1f, 1f, glass(1f, 1f, 1f, 0.9f), attr)));

        Model meteorModel = keep(mb.createSphere(5f, 5f, 5f, 12, 8, solid(1f, 0.45f, 0.2f), attr));
        Model markerModel = keep(mb.createCylinder(7f, 0.1f, 7f, 20, glass(1f, 0.2f, 0.2f, 0.4f), attr));
        for (int i = 0; i < METEORS; i++) {
            meteor[i] = new ModelInstance(meteorModel);
            marker[i] = new ModelInstance(markerModel);
        }
        Model ringModel = keep(mb.createBox(1f, 1f, 1f, glass(0.9f, 0.4f, 1f, 0.85f), attr));
        for (int k = 0; k < RINGS; k++) {
            for (int s = 0; s < SEGS; s++) {
                seg[k][s] = new ModelInstance(ringModel);
            }
        }
        Model hawkModel = keep(mb.createSphere(1.6f, 1.6f, 1.6f, 8, 6, solid(1f, 0.7f, 1f), attr));
        for (int i = 0; i < HAWKS; i++) {
            hawk[i] = new ModelInstance(hawkModel);
        }
        Model cometModel = keep(mb.createBox(3f, 3f, 16f, glass(1f, 0.85f, 0.5f, 0.9f), attr));
        for (int i = 0; i < COMETS; i++) {
            comet[i] = new ModelInstance(cometModel);
        }
        Model waveModel = keep(mb.createBox(1f, 1f, 1f, glass(0.25f, 0.05f, 0.5f, 0.8f), attr));
        for (int i = 0; i < WAVES; i++) {
            wave[i] = new ModelInstance(waveModel);
        }
        Model voidModel = keep(mb.createSphere(8f, 8f, 8f, 20, 14, solid(0.02f, 0f, 0.05f), attr));
        voidInst[0] = new ModelInstance(voidModel);
        voidInst[1] = new ModelInstance(voidModel);
    }

    public void setAnchors(float[] x, float[] z, boolean[] alive) {
        axs = x;
        azs = z;
        aliveRef = alive;
    }

    public void setLock(int g) {
        lockGroup = g;
        if (g >= 0) {
            group = g;
            gt = -1.5f;
            resetFlags();
        }
    }

    public String status() {
        return gt < 0f ? "next: " + NAMES[group] : NAMES[group];
    }

    private void resetFlags() {
        for (int i = 0; i < fired.length; i++) {
            fired[i] = false;
        }
        for (int i = 0; i < anchorCd.length; i++) {
            anchorCd[i] = 0f;
        }
        rzInit = false;
        voidOn = false;
        rainTimer = 0f;
        hawkTimer = 0f;
        cometTimer = 0f;
    }

    private void clearAll() {
        for (int i = 0; i < METEORS; i++) {
            mAlive[i] = false;
        }
        for (int k = 0; k < RINGS; k++) {
            ringAlive[k] = false;
        }
        for (int i = 0; i < HAWKS; i++) {
            hLife[i] = 0f;
        }
        for (int i = 0; i < COMETS; i++) {
            cAlive[i] = false;
        }
        for (int i = 0; i < WAVES; i++) {
            wAlive[i] = false;
        }
        lanceT = 0f;
        histCount = 0;
    }

    public void start() {
        running = true;
        group = lockGroup >= 0 ? lockGroup : 0;
        gt = -3f;
        now = 0f;
        resetFlags();
        clearAll();
        visible.clear();
        pullX = 0f;
        pullZ = 0f;
        speedMul = 1f;
        gravMul = 1f;
        flipTint = 0f;
    }

    public void stop() {
        running = false;
        speedMul = 1f;
        gravMul = 1f;
        flipTint = 0f;
    }

    private static float angDiff(float a, float b) {
        float d = Math.abs(a - b) % 360f;
        return d > 180f ? 360f - d : d;
    }

    private boolean in(float a, float b) {
        return gt >= a && gt < b;
    }

    private boolean evt(int i, float at) {
        if (!fired[i] && gt >= at) {
            fired[i] = true;
            return true;
        }
        return false;
    }

    private void placeBeam(ModelInstance inst, Vector3 a, Vector3 b, float thick) {
        dir.set(b).sub(a);
        float len = dir.len();
        if (len < 0.001f) {
            return;
        }
        dir.scl(1f / len);
        q.setFromCross(Vector3.Z, dir);
        mid.set(a).add(b).scl(0.5f);
        inst.transform.idt().translate(mid).rotate(q).scale(thick, thick, len);
    }

    private static float distPointSeg(float px, float py, float pz, Vector3 a, Vector3 b) {
        float abx = b.x - a.x;
        float aby = b.y - a.y;
        float abz = b.z - a.z;
        float apx = px - a.x;
        float apy = py - a.y;
        float apz = pz - a.z;
        float t = (apx * abx + apy * aby + apz * abz) / (abx * abx + aby * aby + abz * abz);
        t = MathUtils.clamp(t, 0f, 1f);
        float dx = a.x + abx * t - px;
        float dy = a.y + aby * t - py;
        float dz = a.z + abz * t - pz;
        return (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private void spawnMeteor(float px, float pz) {
        for (int i = 0; i < METEORS; i++) {
            if (!mAlive[i]) {
                boolean near = MathUtils.randomBoolean();
                float x = near ? px + MathUtils.random(-16f, 16f) : MathUtils.random(-LIMIT, LIMIT);
                float z = near ? pz + MathUtils.random(-16f, 16f) : MathUtils.random(-LIMIT, LIMIT);
                mx[i] = MathUtils.clamp(x, -LIMIT, LIMIT);
                mz[i] = MathUtils.clamp(z, -LIMIT, LIMIT);
                my[i] = 120f;
                mAlive[i] = true;
                return;
            }
        }
    }

    private void spawnRing(float x, float z, float r0, float rmax, float speed, float gapHalf) {
        for (int k = 0; k < RINGS; k++) {
            if (!ringAlive[k]) {
                ringAlive[k] = true;
                ringR[k] = r0;
                ringMax[k] = rmax;
                ringSp[k] = speed;
                ringGH[k] = gapHalf;
                ringGap[k] = MathUtils.random(0f, 360f);
                ringCX[k] = x;
                ringCZ[k] = z;
                return;
            }
        }
    }

    private void spawnHawk() {
        for (int i = 0; i < HAWKS; i++) {
            if (hLife[i] <= 0f) {
                hx[i] = 0f;
                hy[i] = 62f;
                hz[i] = 0f;
                float a = MathUtils.random(0f, 360f);
                hvx[i] = MathUtils.cosDeg(a) * 22f;
                hvy[i] = MathUtils.random(-8f, 8f);
                hvz[i] = MathUtils.sinDeg(a) * 22f;
                hLife[i] = 7f;
                return;
            }
        }
    }

    private void spawnComet(float px, float pz) {
        for (int i = 0; i < COMETS; i++) {
            if (!cAlive[i]) {
                float a = MathUtils.random(0f, 360f);
                cx[i] = MathUtils.cosDeg(a) * (HALF + 30f);
                cz[i] = MathUtils.sinDeg(a) * (HALF + 30f);
                float tx = px + MathUtils.random(-12f, 12f) - cx[i];
                float tz = pz + MathUtils.random(-12f, 12f) - cz[i];
                float l = (float) Math.sqrt(tx * tx + tz * tz);
                cvx[i] = tx / l * 85f;
                cvz[i] = tz / l * 85f;
                cAlive[i] = true;
                return;
            }
        }
    }

    private void spawnWave() {
        for (int i = 0; i < WAVES; i++) {
            if (!wAlive[i]) {
                wAxis[i] = MathUtils.random(1);
                wDir[i] = MathUtils.randomBoolean() ? 1f : -1f;
                wc[i] = -wDir[i] * (HALF + 10f);
                wAlive[i] = true;
                return;
            }
        }
    }

    private void fireLance(float px, float pz) {
        lagX = px;
        lagZ = pz;
        for (int i = 0; i < histCount; i++) {
            int idx = (histHead - i + HIST) % HIST;
            lagX = hxh[idx];
            lagZ = hzh[idx];
            if (now - hth[idx] >= 0.5f) {
                break;
            }
        }
        lanceA.set(0f, 62f, 0f);
        va.set(lagX, 2.5f, lagZ);
        lanceB.set(va).sub(lanceA).scl(1.5f).add(lanceA);
        lanceT = 0.28f;
    }

    private void runGroup(float dt, float px, float py, float pz) {
        if (group == 0) {
            if (in(0f, 6f)) {
                float dx = -px;
                float dz = -pz;
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                if (d < WELL_R && d > 0.01f) {
                    pullX += dx / d * WELL_PULL * dt;
                    pullZ += dz / d * WELL_PULL * dt;
                }
                if (d < 5f && py < 3f) {
                    hit = true;
                }
                wellDisc.transform.setToTranslation(0f, 0.12f, 0f);
                wellCore.transform.setToTranslation(0f, 0.2f, 0f);
                visible.add(wellDisc);
                visible.add(wellCore);
            }
            if (in(0f, 10f)) {
                rainTimer -= dt;
                if (rainTimer <= 0f) {
                    rainTimer += 0.25f;
                    spawnMeteor(px, pz);
                }
            }
            for (int i = 0; i < RING_TIMES.length; i++) {
                if (evt(i, RING_TIMES[i])) {
                    spawnRing(0f, 0f, 6f, HALF * 1.5f, RING_SPEED, GAP_HALF);
                }
            }
        } else if (group == 1) {
            if (in(0f, 6f) && aliveRef != null) {
                int best = -1;
                float bd = 1e9f;
                for (int k = 0; k < aliveRef.length; k++) {
                    if (aliveRef[k]) {
                        float dx = axs[k] - px;
                        float dz = azs[k] - pz;
                        float d2 = dx * dx + dz * dz;
                        if (d2 < bd) {
                            bd = d2;
                            best = k;
                        }
                    }
                }
                if (best >= 0) {
                    float d = (float) Math.sqrt(bd);
                    if (d > 0.01f) {
                        pullX += (axs[best] - px) / d * SPAG_PULL * dt;
                        pullZ += (azs[best] - pz) / d * SPAG_PULL * dt;
                    }
                    if (d < 8f && py < 14f) {
                        hit = true;
                    }
                    va.set(px, py + 2.5f, pz);
                    vb.set(axs[best], 5f, azs[best]);
                    placeBeam(spagBeam, va, vb, 0.8f);
                    hotDisc.transform.setToTranslation(axs[best], 0.14f, azs[best]);
                    visible.add(spagBeam);
                    visible.add(hotDisc);
                }
            }
            for (int i = 0; i < 8; i++) {
                if (evt(i, 1f + 1.2f * i)) {
                    fireLance(px, pz);
                }
            }
        } else if (group == 2) {
            if (in(0f, 12f)) {
                if (!rzInit) {
                    rzInit = true;
                    rzX = px + 30f;
                    rzZ = pz;
                }
                float dx = px - rzX;
                float dz = pz - rzZ;
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                float step = 10f * dt;
                if (d > step) {
                    rzX += dx / d * step;
                    rzZ += dz / d * step;
                } else {
                    rzX = px;
                    rzZ = pz;
                }
                if (d < 14f) {
                    speedMul = 0.5f;
                }
                rzDisc.transform.setToTranslation(rzX, 0.16f, rzZ);
                visible.add(rzDisc);
                hawkTimer -= dt;
                if (hawkTimer <= 0f) {
                    hawkTimer += 0.15f;
                    spawnHawk();
                }
            }
            if (evt(0, 2f) || evt(1, 5.5f) || evt(2, 9f)) {
                spawnWave();
            }
        } else if (group == 3) {
            if (evt(0, 0.2f)) {
                voidOn = true;
                voidT = 0f;
                voidA0 = MathUtils.random(0f, 360f);
            }
            if (in(1f, 11f)) {
                cometTimer -= dt;
                if (cometTimer <= 0f) {
                    cometTimer += 0.8f;
                    spawnComet(px, pz);
                }
            }
        } else {
            if (in(2f, 3.4f) || in(7f, 8.4f)) {
                gravMul = -0.25f;
                flipTint = 1f;
            } else if (in(3.4f, 4.2f) || in(8.4f, 9.2f)) {
                gravMul = 1.8f;
                flipTint = 1f;
            }
            if (aliveRef != null) {
                for (int k = 0; k < aliveRef.length; k++) {
                    anchorCd[k] -= dt;
                    if (aliveRef[k] && anchorCd[k] <= 0f) {
                        float dx = axs[k] - px;
                        float dz = azs[k] - pz;
                        if (dx * dx + dz * dz < 32f * 32f) {
                            spawnRing(axs[k], azs[k], 3f, 60f, 40f, 0f);
                            anchorCd[k] = 1.6f;
                        }
                    }
                }
            }
        }
    }

    public boolean update(float dt, float px, float py, float pz) {
        pullX = 0f;
        pullZ = 0f;
        speedMul = 1f;
        gravMul = 1f;
        flipTint = 0f;
        hit = false;
        if (!running) {
            return false;
        }
        visible.clear();
        now += dt;
        histHead = (histHead + 1) % HIST;
        hxh[histHead] = px;
        hzh[histHead] = pz;
        hth[histHead] = now;
        if (histCount < HIST) {
            histCount++;
        }

        gt += dt;
        if (gt >= GDUR[group]) {
            group = lockGroup >= 0 ? lockGroup : (group + 1) % NAMES.length;
            gt = -PAUSE;
            resetFlags();
        }
        if (gt >= 0f) {
            runGroup(dt, px, py, pz);
        }
        float atk = (group == 2 && gt >= 0f) ? 1.35f : 1f;

        for (int i = 0; i < METEORS; i++) {
            if (!mAlive[i]) {
                continue;
            }
            my[i] -= METEOR_SPEED * atk * dt;
            if (my[i] <= 2.5f) {
                mAlive[i] = false;
                continue;
            }
            meteor[i].transform.setToTranslation(mx[i], my[i], mz[i]);
            marker[i].transform.setToTranslation(mx[i], 0.1f, mz[i]);
            visible.add(marker[i]);
            visible.add(meteor[i]);
            float dx = px - mx[i];
            float dz = pz - mz[i];
            if (dx * dx + dz * dz < 3.4f * 3.4f && my[i] > py - 1f && my[i] < py + 6.5f) {
                hit = true;
            }
        }

        for (int k = 0; k < RINGS; k++) {
            if (!ringAlive[k]) {
                continue;
            }
            ringR[k] += ringSp[k] * atk * dt;
            float r = ringR[k];
            if (r > ringMax[k]) {
                ringAlive[k] = false;
                continue;
            }
            float segW = (float) (2.0 * Math.PI * r / SEGS) * 1.03f;
            for (int s = 0; s < SEGS; s++) {
                float a = s * 360f / SEGS;
                if (angDiff(a, ringGap[k]) < ringGH[k]) {
                    continue;
                }
                seg[k][s].transform.setToTranslation(ringCX[k] + r * MathUtils.cosDeg(a), 2f,
                        ringCZ[k] + r * MathUtils.sinDeg(a)).rotate(Vector3.Y, -a).scale(1.4f, 4f, segW);
                visible.add(seg[k][s]);
            }
            float rdx = px - ringCX[k];
            float rdz = pz - ringCZ[k];
            float pAng = MathUtils.atan2(rdz, rdx) * MathUtils.radiansToDegrees;
            if (pAng < 0f) {
                pAng += 360f;
            }
            float pDist = (float) Math.sqrt(rdx * rdx + rdz * rdz);
            if (Math.abs(pDist - r) < 2.4f && py < 4.2f && angDiff(pAng, ringGap[k]) >= ringGH[k]) {
                hit = true;
            }
        }

        for (int i = 0; i < HAWKS; i++) {
            if (hLife[i] <= 0f) {
                continue;
            }
            hLife[i] -= dt;
            float tx = px - hx[i];
            float ty = py + 2.5f - hy[i];
            float tz = pz - hz[i];
            float l = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
            if (l > 0.01f) {
                float f = Math.min(1f, 1.4f * dt);
                hvx[i] += (tx / l * 38f - hvx[i]) * f;
                hvy[i] += (ty / l * 38f - hvy[i]) * f;
                hvz[i] += (tz / l * 38f - hvz[i]) * f;
            }
            hx[i] += hvx[i] * dt;
            hy[i] += hvy[i] * dt;
            hz[i] += hvz[i] * dt;
            if (l < 2f) {
                hit = true;
                hLife[i] = 0f;
                continue;
            }
            hawk[i].transform.setToTranslation(hx[i], hy[i], hz[i]);
            visible.add(hawk[i]);
        }

        for (int i = 0; i < COMETS; i++) {
            if (!cAlive[i]) {
                continue;
            }
            cx[i] += cvx[i] * atk * dt;
            cz[i] += cvz[i] * atk * dt;
            if (Math.abs(cx[i]) > HALF + 60f || Math.abs(cz[i]) > HALF + 60f) {
                cAlive[i] = false;
                continue;
            }
            float len = (float) Math.sqrt(cvx[i] * cvx[i] + cvz[i] * cvz[i]);
            float ux = cvx[i] / len;
            float uz = cvz[i] / len;
            comet[i].transform.setToTranslation(cx[i], 2.5f, cz[i])
                    .rotate(Vector3.Y, MathUtils.atan2(ux, uz) * MathUtils.radiansToDegrees);
            visible.add(comet[i]);
            float dx = px - cx[i];
            float dz = pz - cz[i];
            float along = dx * ux + dz * uz;
            float perp = Math.abs(dx * uz - dz * ux);
            if (Math.abs(along) < 9f && perp < 2.6f && py < 5.5f) {
                hit = true;
            }
        }

        for (int i = 0; i < WAVES; i++) {
            if (!wAlive[i]) {
                continue;
            }
            wc[i] += wDir[i] * 70f * atk * dt;
            if (Math.abs(wc[i]) > HALF + 14f) {
                wAlive[i] = false;
                continue;
            }
            float span = 2f * (HALF + 8f);
            if (wAxis[i] == 0) {
                wave[i].transform.setToTranslation(wc[i], 3f, 0f).scale(4f, 6f, span);
                if (Math.abs(px - wc[i]) < 2.8f && py < 6.2f) {
                    hit = true;
                }
            } else {
                wave[i].transform.setToTranslation(0f, 3f, wc[i]).scale(span, 6f, 4f);
                if (Math.abs(pz - wc[i]) < 2.8f && py < 6.2f) {
                    hit = true;
                }
            }
            visible.add(wave[i]);
        }

        if (voidOn) {
            voidT += dt;
            float u = voidT / 9f;
            float rad = HALF * 0.6f * (1f - u) + 3f;
            float ang = voidA0 + 30f * voidT;
            for (int v = 0; v < 2; v++) {
                float a = ang + 180f * v;
                float x = MathUtils.cosDeg(a) * rad;
                float z = MathUtils.sinDeg(a) * rad;
                voidInst[v].transform.setToTranslation(x, 4f, z);
                visible.add(voidInst[v]);
                float dx = x - px;
                float dz = z - pz;
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                if (d < 45f && d > 0.01f) {
                    pullX += dx / d * 16f * dt;
                    pullZ += dz / d * 16f * dt;
                }
                if (d < 5.5f && py < 9f) {
                    hit = true;
                }
            }
            if (voidT >= 9f) {
                voidOn = false;
                spawnRing(0f, 0f, 4f, HALF * 1.5f, 70f, 0f);
            }
        }

        if (lanceT > 0f) {
            lanceT -= dt;
            placeBeam(lanceInst, lanceA, lanceB, 2.2f);
            visible.add(lanceInst);
            if (distPointSeg(px, py + 2.5f, pz, lanceA, lanceB) < 2.4f) {
                hit = true;
            }
        }
        return hit;
    }

    public void dispose() {
        for (Model m : models) {
            m.dispose();
        }
    }
}
