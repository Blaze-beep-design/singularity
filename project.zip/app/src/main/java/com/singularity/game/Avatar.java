package com.singularity.game;

import com.badlogic.gdx.graphics.VertexAttributes.Usage;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;

public class Avatar {
    public boolean visible = true;

    private final Array<Model> models = new Array<Model>();
    private final Array<ModelInstance> parts = new Array<ModelInstance>();
    private final ModelInstance head, torso, armL, armR, legL, legR, eyeL, eyeR, mouth;
    private final Matrix4 root = new Matrix4();

    private float phase;
    private float time;
    private float moveBlend;
    private float airBlend;

    private ModelInstance box(ModelBuilder mb, float w, float h, float d, float r, float g, float b) {
        Material m = new Material(ColorAttribute.createDiffuse(r, g, b, 1f));
        Model model = mb.createBox(w, h, d, m, Usage.Position | Usage.Normal);
        models.add(model);
        ModelInstance inst = new ModelInstance(model);
        parts.add(inst);
        return inst;
    }

    public Avatar() {
        ModelBuilder mb = new ModelBuilder();
        legR = box(mb, 1f, 2f, 1f, 0.12f, 0.55f, 0.25f);
        legL = box(mb, 1f, 2f, 1f, 0.12f, 0.55f, 0.25f);
        torso = box(mb, 2f, 2f, 1f, 0.15f, 0.45f, 0.95f);
        armR = box(mb, 1f, 2f, 1f, 0.97f, 0.82f, 0.25f);
        armL = box(mb, 1f, 2f, 1f, 0.97f, 0.82f, 0.25f);
        head = box(mb, 1.2f, 1.2f, 1.2f, 0.97f, 0.82f, 0.25f);
        eyeL = box(mb, 0.16f, 0.22f, 0.04f, 0.05f, 0.05f, 0.05f);
        eyeR = box(mb, 0.16f, 0.22f, 0.04f, 0.05f, 0.05f, 0.05f);
        mouth = box(mb, 0.46f, 0.07f, 0.04f, 0.05f, 0.05f, 0.05f);
    }

    public void update(float dt, float x, float y, float z, float heading,
                       float speed, boolean grounded) {
        time += dt;
        phase += dt * speed * 0.55f;
        float targetMove = MathUtils.clamp(speed / 12f, 0f, 1f);
        moveBlend = MathUtils.lerp(moveBlend, targetMove, Math.min(1f, 12f * dt));
        airBlend = MathUtils.lerp(airBlend, grounded ? 0f : 1f, Math.min(1f, 10f * dt));

        float walk = moveBlend * (1f - airBlend);
        float swing = MathUtils.sin(phase) * 50f * walk;
        float idle = MathUtils.sin(time * 1.6f) * 3f * (1f - moveBlend) * (1f - airBlend);

        float legRAngle = MathUtils.lerp(swing, 15f, airBlend);
        float legLAngle = MathUtils.lerp(-swing, -15f, airBlend);
        float armRAngle = MathUtils.lerp(-swing + idle, -150f, airBlend);
        float armLAngle = MathUtils.lerp(swing - idle, -150f, airBlend);

        float up = Math.abs(MathUtils.sin(phase)) * 0.12f * walk
                + MathUtils.sin(time * 2f) * 0.03f * (1f - moveBlend);

        root.idt().translate(x, y, z).rotate(Vector3.Y, heading);

        legR.transform.set(root).translate(-0.5f, 2f, 0f).rotate(Vector3.X, legRAngle).translate(0f, -1f, 0f);
        legL.transform.set(root).translate(0.5f, 2f, 0f).rotate(Vector3.X, legLAngle).translate(0f, -1f, 0f);
        torso.transform.set(root).translate(0f, 3f + up, 0f);
        armR.transform.set(root).translate(-1.5f, 4f + up, 0f).rotate(Vector3.X, armRAngle).translate(0f, -1f, 0f);
        armL.transform.set(root).translate(1.5f, 4f + up, 0f).rotate(Vector3.X, armLAngle).translate(0f, -1f, 0f);
        head.transform.set(root).translate(0f, 4.6f + up, 0f);
        eyeL.transform.set(head.transform).translate(0.28f, 0.1f, 0.61f);
        eyeR.transform.set(head.transform).translate(-0.28f, 0.1f, 0.61f);
        mouth.transform.set(head.transform).translate(0f, -0.3f, 0.61f);
    }

    public void render(ModelBatch batch, Environment env) {
        if (visible) {
            batch.render(parts, env);
        }
    }

    public void dispose() {
        for (Model m : models) {
            m.dispose();
        }
    }
}
