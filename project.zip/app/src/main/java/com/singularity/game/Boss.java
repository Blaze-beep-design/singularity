package com.singularity.game;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g3d.decals.Decal;
import com.badlogic.gdx.graphics.g3d.decals.DecalBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;

public class Boss {
    public static final float R = 18f;
    private static final float L1 = 20f;
    private static final float L2 = 22f;
    private static final float[] BASE = {135f, 45f, 205f, 335f, 250f, 290f};

    public final Vector3 pos = new Vector3(0f, 62f, 0f);

    private final Array<Decal> all = new Array<Decal>();
    private final Array<Texture> textures = new Array<Texture>();
    private final Decal disc, ring1, ring2, coreRim, core, eyeW, eyeP;
    private final Decal[] seg1 = new Decal[6];
    private final Decal[] seg2 = new Decal[6];
    private final Decal[] joint = new Decal[6];
    private final Vector3 right = new Vector3();
    private final Vector3 back = new Vector3(0f, 0f, -1f);
    private final Vector3 tmp = new Vector3();
    private final Vector3 look = new Vector3();

    private Texture finish(Pixmap p) {
        Texture t = new Texture(p);
        t.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        p.dispose();
        textures.add(t);
        return t;
    }

    private Texture makeCircle() {
        Pixmap p = new Pixmap(256, 256, Pixmap.Format.RGBA8888);
        p.setColor(1f, 1f, 1f, 1f);
        p.fillCircle(128, 128, 126);
        return finish(p);
    }

    private Texture makeArcs() {
        Pixmap p = new Pixmap(512, 512, Pixmap.Format.RGBA8888);
        p.setColor(1f, 1f, 1f, 1f);
        for (float d = 0f; d < 360f; d += 0.3f) {
            if (d % 120f < 80f) {
                int x = 256 + (int) (240f * MathUtils.cosDeg(d));
                int y = 256 + (int) (240f * MathUtils.sinDeg(d));
                p.fillCircle(x, y, 4);
            }
        }
        return finish(p);
    }

    private Texture makeEllipse() {
        Pixmap p = new Pixmap(512, 512, Pixmap.Format.RGBA8888);
        p.setColor(1f, 1f, 1f, 1f);
        for (float d = 0f; d < 360f; d += 0.2f) {
            int x = 256 + (int) (244f * MathUtils.cosDeg(d));
            int y = 256 + (int) (70f * MathUtils.sinDeg(d));
            p.fillCircle(x, y, 5);
        }
        return finish(p);
    }

    private Texture makeBar() {
        Pixmap p = new Pixmap(128, 32, Pixmap.Format.RGBA8888);
        p.setColor(1f, 1f, 1f, 1f);
        p.fillRectangle(16, 0, 96, 32);
        p.fillCircle(16, 16, 16);
        p.fillCircle(112, 16, 16);
        return finish(p);
    }

    private Decal decal(Texture t, float w, float h, float r, float g, float b, float a) {
        Decal d = Decal.newDecal(w, h, new TextureRegion(t), true);
        d.setColor(r, g, b, a);
        all.add(d);
        return d;
    }

    public Boss() {
        Texture circle = makeCircle();
        Texture arcs = makeArcs();
        Texture ellipse = makeEllipse();
        Texture bar = makeBar();
        for (int i = 0; i < 6; i++) {
            seg1[i] = decal(bar, L1 + 1f, 2.6f, 0.55f, 0.42f, 0.85f, 1f);
            seg2[i] = decal(bar, L2 + 1f, 1.9f, 0.55f, 0.42f, 0.85f, 1f);
            joint[i] = decal(circle, 3.4f, 3.4f, 0.75f, 0.62f, 1f, 1f);
        }
        ring1 = decal(arcs, 62f, 62f, 0.7f, 0.3f, 1f, 0.85f);
        ring2 = decal(arcs, 80f, 80f, 0.45f, 0.3f, 1f, 0.6f);
        disc = decal(ellipse, 110f, 110f, 1f, 0.55f, 0.35f, 0.85f);
        coreRim = decal(circle, 2f * R + 1.6f, 2f * R + 1.6f, 0.95f, 0.9f, 1f, 1f);
        core = decal(circle, 2f * R, 2f * R, 0f, 0f, 0f, 1f);
        eyeW = decal(circle, 5.5f, 15f, 1f, 1f, 1f, 1f);
        eyeP = decal(circle, 2.2f, 13f, 0f, 0f, 0f, 1f);
    }

    private void place(Decal d, float x, float y, int layer, float rot, float w, float h) {
        float off = layer * 1.5f;
        tmp.set(pos.x + right.x * x + back.x * off, pos.y + y, pos.z + right.z * x + back.z * off);
        d.setPosition(tmp.x, tmp.y, tmp.z);
        d.setDimensions(w, h);
        d.lookAt(look.set(tmp).add(back), Vector3.Y);
        d.rotateZ(rot);
    }

    public void update(Camera cam) {
        float hl = (float) Math.sqrt(cam.direction.x * cam.direction.x + cam.direction.z * cam.direction.z);
        if (hl > 0.001f) {
            back.set(-cam.direction.x / hl, 0f, -cam.direction.z / hl);
        }
        right.set(back.z, 0f, -back.x);

        for (int i = 0; i < 6; i++) {
            float a = BASE[i];
            float t1 = a;
            float t2 = a + ((i % 2 == 0) ? 28f : -28f);
            float rx = MathUtils.cosDeg(a) * R * 0.9f;
            float ry = MathUtils.sinDeg(a) * R * 0.9f;
            float x1 = rx + L1 * MathUtils.cosDeg(t1);
            float y1 = ry + L1 * MathUtils.sinDeg(t1);
            float x2 = x1 + L2 * MathUtils.cosDeg(t2);
            float y2 = y1 + L2 * MathUtils.sinDeg(t2);
            place(seg1[i], (rx + x1) / 2f, (ry + y1) / 2f, 0, t1, L1 + 1f, 2.6f);
            place(seg2[i], (x1 + x2) / 2f, (y1 + y2) / 2f, 0, t2, L2 + 1f, 1.9f);
            place(joint[i], x1, y1, 1, 0f, 3.4f, 3.4f);
        }
        place(ring1, 0f, 0f, 2, 0f, 62f, 62f);
        place(ring2, 0f, 0f, 2, 40f, 80f, 80f);
        place(disc, 0f, 0f, 3, -16f, 110f, 110f);
        place(coreRim, 0f, 0f, 4, 0f, 2f * R + 1.6f, 2f * R + 1.6f);
        place(core, 0f, 0f, 5, 0f, 2f * R, 2f * R);
        place(eyeW, 0f, 0f, 6, 0f, 5.5f, 15f);
        place(eyeP, 0f, -0.6f, 7, 0f, 2.2f, 13f);
    }

    public void render(DecalBatch batch) {
        for (Decal d : all) {
            batch.add(d);
        }
    }

    public void dispose() {
        for (Texture t : textures) {
            t.dispose();
        }
    }
}
