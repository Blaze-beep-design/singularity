package com.singularity.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes.Usage;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.decals.CameraGroupStrategy;
import com.badlogic.gdx.graphics.g3d.decals.DecalBatch;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;

public class SingularityGame extends ApplicationAdapter {
    static final float BASE_SPEED = 22f;
    static final float JUMP_POWER = 60f;
    static final float GRAVITY = 196.2f;
    static final float HALF = 300f;
    static final float MIN_ZOOM = 0.5f;
    static final float MAX_ZOOM = 100f;
    static final float HEAD_HEIGHT = 4.5f;
    static final int ANCHORS = 5;

    static final int S_MENU = 0;
    static final int S_PLAY = 1;
    static final int S_DEAD = 2;
    static final int S_WON = 3;

    static final int B_PLAY = 1;
    static final int B_SH_DN = 2;
    static final int B_SH_UP = 3;
    static final int B_DJ_DN = 4;
    static final int B_DJ_UP = 5;
    static final int B_SP_DN = 6;
    static final int B_SP_UP = 7;
    static final int B_GOD = 8;
    static final int B_RETRY = 9;
    static final int B_MENU = 10;
    static final int B_GROUP = 11;

    private PerspectiveCamera cam;
    private ModelBatch modelBatch;
    private DecalBatch decalBatch;
    private Environment env;
    private final Array<ModelInstance> world = new Array<ModelInstance>();
    private final Array<Model> models = new Array<Model>();
    private ModelInstance shadow;
    private Avatar avatar;
    private Boss boss;
    private Attacks attacks;

    private final ModelInstance[] anc = new ModelInstance[ANCHORS];
    private final float[] ax = new float[ANCHORS];
    private final float[] az = new float[ANCHORS];
    private final boolean[] aAlive = new boolean[ANCHORS];
    private final Array<ModelInstance> ancVisible = new Array<ModelInstance>();
    private int anchorsLeft;

    private ShapeRenderer shapes;
    private SpriteBatch sb;
    private BitmapFont font;
    private final GlyphLayout layout = new GlyphLayout();
    private final Matrix4 hud = new Matrix4();
    private TouchControls controls;
    private Ui ui;

    private int state = S_MENU;
    private int upShield, upDouble, upSpeed;
    private boolean godMode;
    private int groupSel = -1;
    private int shields, airJumpsLeft;
    private float walkSpeed = BASE_SPEED;
    private float invuln, flashRed, flashBlue, runTime, finalTime, time;

    private float px, py, pz, vy, heading;
    private boolean grounded;
    private float camYaw, camPitch;
    private float camDist = 14f;

    private Material mat(float r, float g, float b) {
        return new Material(ColorAttribute.createDiffuse(r, g, b, 1f));
    }

    private Model track(Model m) {
        models.add(m);
        return m;
    }

    private ModelInstance place(Model m, float x, float y, float z) {
        ModelInstance inst = new ModelInstance(m);
        inst.transform.setToTranslation(x, y, z);
        world.add(inst);
        return inst;
    }

    @Override
    public void create() {
        int w = Gdx.graphics.getWidth();
        int h = Gdx.graphics.getHeight();

        modelBatch = new ModelBatch();
        env = new Environment();
        env.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.45f, 0.45f, 0.55f, 1f));
        env.add(new DirectionalLight().set(0.9f, 0.85f, 1f, -0.5f, -1f, -0.3f));

        ModelBuilder mb = new ModelBuilder();
        long attr = Usage.Position | Usage.Normal;

        place(track(mb.createBox(HALF * 2f, 2f, HALF * 2f, mat(0.12f, 0.10f, 0.20f), attr)), 0f, -1f, 0f);

        Model lineX = track(mb.createBox(0.4f, 0.1f, HALF * 2f, mat(0.35f, 0.25f, 0.6f), attr));
        Model lineZ = track(mb.createBox(HALF * 2f, 0.1f, 0.4f, mat(0.35f, 0.25f, 0.6f), attr));
        for (int i = -12; i <= 12; i++) {
            float c = i * 25f;
            place(lineX, c, 0.05f, 0f);
            place(lineZ, 0f, 0.05f, c);
        }

        Model tower = track(mb.createBox(6f, 40f, 6f, mat(0.5f, 0.2f, 0.9f), attr));
        place(tower, HALF, 20f, HALF);
        place(tower, -HALF, 20f, HALF);
        place(tower, HALF, 20f, -HALF);
        place(tower, -HALF, 20f, -HALF);

        shadow = place(track(mb.createCylinder(2.6f, 0.05f, 2.6f, 20, mat(0.02f, 0.01f, 0.04f), attr)),
                0f, 0.06f, 0f);

        Model anchorModel = track(mb.createBox(3f, 10f, 3f, mat(0.3f, 0.9f, 1f), attr));
        for (int k = 0; k < ANCHORS; k++) {
            float ang = 90f + 72f * k;
            ax[k] = 200f * MathUtils.cosDeg(ang);
            az[k] = 200f * MathUtils.sinDeg(ang);
            anc[k] = new ModelInstance(anchorModel);
        }

        avatar = new Avatar();
        attacks = new Attacks();
        attacks.setAnchors(ax, az, aAlive);

        cam = new PerspectiveCamera(67f, w, h);
        cam.near = 0.3f;
        cam.far = 1500f;
        decalBatch = new DecalBatch(new CameraGroupStrategy(cam));
        boss = new Boss();

        shapes = new ShapeRenderer();
        sb = new SpriteBatch();
        font = new BitmapFont();
        font.getData().setScale(2f);
        hud.setToOrtho2D(0f, 0f, w, h);

        ui = new Ui();
        controls = new TouchControls();
        controls.ui = ui;
        controls.enabled = false;
        Gdx.input.setInputProcessor(controls);

        respawn();
    }

    private void respawn() {
        px = 0f;
        py = 0f;
        pz = 120f;
        vy = 0f;
        heading = 180f;
        grounded = true;
        camYaw = 180f;
        camPitch = 15f;
    }

    private void startRun() {
        respawn();
        walkSpeed = BASE_SPEED + 5f * upSpeed;
        shields = upShield;
        airJumpsLeft = upDouble;
        invuln = 0f;
        flashRed = 0f;
        flashBlue = 0f;
        runTime = 0f;
        anchorsLeft = ANCHORS;
        for (int k = 0; k < ANCHORS; k++) {
            aAlive[k] = true;
        }
        attacks.start();
        controls.reset();
        controls.enabled = true;
        state = S_PLAY;
    }

    private void goMenu() {
        state = S_MENU;
        attacks.stop();
        controls.reset();
        controls.enabled = false;
    }

    private void handlePress(int id) {
        switch (id) {
            case B_PLAY:
            case B_RETRY:
                startRun();
                break;
            case B_MENU:
                goMenu();
                break;
            case B_SH_DN:
                upShield = Math.max(0, upShield - 1);
                break;
            case B_SH_UP:
                upShield = Math.min(3, upShield + 1);
                break;
            case B_DJ_DN:
                upDouble = Math.max(0, upDouble - 1);
                break;
            case B_DJ_UP:
                upDouble = Math.min(3, upDouble + 1);
                break;
            case B_SP_DN:
                upSpeed = Math.max(0, upSpeed - 1);
                break;
            case B_SP_UP:
                upSpeed = Math.min(10, upSpeed + 1);
                break;
            case B_GOD:
                godMode = !godMode;
                break;
            case B_GROUP:
                groupSel++;
                if (groupSel > 4) {
                    groupSel = -1;
                }
                attacks.setLock(groupSel);
                break;
            default:
                break;
        }
    }

    private void onHit() {
        if (invuln > 0f) {
            return;
        }
        if (godMode) {
            flashRed = 0.25f;
            return;
        }
        if (shields > 0) {
            shields--;
            invuln = 1.5f;
            flashBlue = 0.3f;
            return;
        }
        flashRed = 0.4f;
        state = S_DEAD;
        controls.enabled = false;
        controls.reset();
        attacks.stop();
    }

    private void update(float dt) {
        time += dt;
        runTime += dt;
        invuln = Math.max(0f, invuln - dt);
        flashRed = Math.max(0f, flashRed - dt);
        flashBlue = Math.max(0f, flashBlue - dt);

        camYaw += controls.consumeYaw();
        camPitch = MathUtils.clamp(camPitch + controls.consumePitch(), -30f, 80f);
        camDist = MathUtils.clamp(
                camDist * (float) Math.exp(-controls.consumeZoom() * 0.002f), MIN_ZOOM, MAX_ZOOM);

        float fwdX = MathUtils.sinDeg(camYaw);
        float fwdZ = MathUtils.cosDeg(camYaw);
        float rightX = -fwdZ;
        float rightZ = fwdX;

        float sx = controls.moveX;
        float sy = controls.moveY;
        if (sx * sx + sy * sy < 0.01f) {
            sx = 0f;
            sy = 0f;
        }
        float dirX = fwdX * sy + rightX * sx;
        float dirZ = fwdZ * sy + rightZ * sx;
        float len = (float) Math.sqrt(dirX * dirX + dirZ * dirZ);
        if (len > 1f) {
            dirX /= len;
            dirZ /= len;
            len = 1f;
        }

        px += dirX * walkSpeed * attacks.speedMul * dt;
        pz += dirZ * walkSpeed * attacks.speedMul * dt;
        if (len > 0.05f) {
            float target = MathUtils.atan2(dirX, dirZ) * MathUtils.radiansToDegrees;
            heading = MathUtils.lerpAngleDeg(heading, target, Math.min(1f, 14f * dt));
        }

        boolean jumpPress = controls.consumeJumpPress();
        if (grounded && controls.jumpHeld) {
            vy = JUMP_POWER;
            grounded = false;
        } else if (!grounded && jumpPress && airJumpsLeft > 0) {
            vy = JUMP_POWER;
            airJumpsLeft--;
        }
        vy -= GRAVITY * attacks.gravMul * dt;
        py += vy * dt;

        boolean hit = attacks.update(dt, px, py, pz);
        px += attacks.pullX;
        pz += attacks.pullZ;

        boolean overPlatform = Math.abs(px) <= HALF && Math.abs(pz) <= HALF;
        if (overPlatform && py <= 0f && vy <= 0f) {
            py = 0f;
            vy = 0f;
            grounded = true;
            airJumpsLeft = upDouble;
        } else {
            grounded = false;
        }
        if (py < -60f) {
            respawn();
        }

        for (int k = 0; k < ANCHORS; k++) {
            if (aAlive[k]) {
                float dx = px - ax[k];
                float dz = pz - az[k];
                if (dx * dx + dz * dz < 5.5f * 5.5f && py < 14f) {
                    aAlive[k] = false;
                    anchorsLeft--;
                }
            }
        }
        if (anchorsLeft <= 0) {
            finalTime = runTime;
            state = S_WON;
            controls.enabled = false;
            controls.reset();
            attacks.stop();
        } else if (hit) {
            onHit();
        }

        float dx = MathUtils.sinDeg(camYaw) * MathUtils.cosDeg(camPitch);
        float dy = -MathUtils.sinDeg(camPitch);
        float dz = MathUtils.cosDeg(camYaw) * MathUtils.cosDeg(camPitch);
        float tx = px;
        float ty = py + HEAD_HEIGHT;
        float tz = pz;
        cam.position.set(tx - dx * camDist, ty - dy * camDist, tz - dz * camDist);
        if (cam.position.y < 0.5f) {
            cam.position.y = 0.5f;
        }
        cam.up.set(0f, 1f, 0f);
        cam.lookAt(tx, ty, tz);
        cam.update();
        boss.update(cam);

        avatar.visible = camDist > 2f && (invuln <= 0f || ((int) (time * 14f)) % 2 == 0);
        avatar.update(dt, px, py, pz, heading, len * walkSpeed, grounded);

        if (overPlatform) {
            float s = MathUtils.clamp(1f - py / 30f, 0.3f, 1f);
            shadow.transform.idt().translate(px, 0.06f, pz).scale(s, 1f, s);
        } else {
            shadow.transform.idt().translate(0f, -200f, 0f);
        }
    }

    private void draw3d() {
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);
        ancVisible.clear();
        for (int k = 0; k < ANCHORS; k++) {
            if (aAlive[k]) {
                anc[k].transform.setToTranslation(ax[k], 6f, az[k]).rotate(Vector3.Y, time * 60f);
                ancVisible.add(anc[k]);
            }
        }
        modelBatch.begin(cam);
        modelBatch.render(world, env);
        modelBatch.render(ancVisible, env);
        modelBatch.render(attacks.visible, env);
        avatar.render(modelBatch, env);
        modelBatch.end();
        boss.render(decalBatch);
        decalBatch.flush();
    }

    private void centerText(String s, float scale, float w, float y) {
        font.getData().setScale(scale);
        layout.setText(font, s);
        sb.begin();
        font.draw(sb, s, (w - layout.width) / 2f, y);
        sb.end();
        font.getData().setScale(2f);
    }

    private void tint(float r, float g, float b, float a, float w, float h) {
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(r, g, b, a);
        shapes.rect(0f, 0f, w, h);
        shapes.end();
    }

    private void menuUi(float w, float h) {
        centerText("SINGULARITY", 5f, w, h * 0.93f);
        centerText("Phase 1 test build", 2f, w, h * 0.78f);
        String[] names = {"Shields", "Double jumps", "Speed +5 each"};
        int[] vals = {upShield, upDouble, upSpeed};
        int[] max = {3, 3, 10};
        sb.begin();
        for (int r = 0; r < 3; r++) {
            float y = h * (0.58f - 0.15f * r);
            font.draw(sb, names[r], w * 0.2f, y + h * 0.075f + 14f);
            font.draw(sb, vals[r] + "/" + max[r], w * 0.575f, y + h * 0.075f + 14f);
            ui.add(B_SH_DN + 2 * r, "-", w * 0.5f, y, h * 0.1f, h * 0.1f, false);
            ui.add(B_SH_UP + 2 * r, "+", w * 0.66f, y, h * 0.1f, h * 0.1f, false);
        }
        sb.end();
        ui.add(B_PLAY, "PLAY", w * 0.5f - h * 0.22f, h * 0.07f, h * 0.44f, h * 0.15f, false);
    }

    private void pips(float x, float y, int max, int have, float r, float g, float b) {
        for (int i = 0; i < max; i++) {
            shapes.setColor(r, g, b, i < have ? 0.95f : 0.2f);
            shapes.circle(x + i * 46f, y, 17f);
        }
    }

    private void drawPips(float h) {
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        pips(250f, h - 205f, upShield, shields, 0.3f, 0.65f, 1f);
        pips(250f, h - 260f, upDouble, airJumpsLeft, 0.4f, 1f, 0.5f);
        shapes.end();
    }

    private void playHud(float w, float h) {
        controls.draw(shapes);
        if (flashRed > 0f) {
            tint(1f, 0.1f, 0.1f, Math.min(0.4f, flashRed * 1.6f), w, h);
        }
        if (flashBlue > 0f) {
            tint(0.2f, 0.5f, 1f, Math.min(0.4f, flashBlue * 1.6f), w, h);
        }
        if (attacks.flipTint > 0f) {
            tint(0.6f, 0.2f, 1f, 0.22f, w, h);
        }
        drawPips(h);
        sb.begin();
        font.draw(sb, "FPS " + Gdx.graphics.getFramesPerSecond(), 30f, h - 30f);
        font.draw(sb, "Anchors " + anchorsLeft + "/" + ANCHORS, 30f, h - 85f);
        font.draw(sb, "Attack: " + attacks.status(), 30f, h - 140f);
        if (upShield > 0) {
            font.draw(sb, "Shield", 30f, h - 191f);
        }
        if (upDouble > 0) {
            font.draw(sb, "Air jumps", 30f, h - 246f);
        }
        sb.end();
        ui.add(B_GOD, godMode ? "GOD MODE: ON" : "GOD MODE: OFF",
                w - h * 0.5f, h - h * 0.15f, h * 0.42f, h * 0.11f, godMode);
        ui.add(B_MENU, "MENU", w - h * 0.5f - h * 0.24f, h - h * 0.15f, h * 0.2f, h * 0.11f, false);
        ui.add(B_GROUP, "GROUP: " + (groupSel < 0 ? "AUTO" : Attacks.NAMES[groupSel]),
                w - h * 0.5f, h - h * 0.29f, h * 0.42f, h * 0.11f, groupSel >= 0);
    }

    @Override
    public void render() {
        float dt = Math.min(Gdx.graphics.getDeltaTime(), 0.05f);
        handlePress(ui.consume());
        if (state == S_PLAY) {
            update(dt);
        }
        float w = Gdx.graphics.getWidth();
        float h = Gdx.graphics.getHeight();

        Gdx.gl.glClearColor(0.04f, 0.02f, 0.07f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        if (state != S_MENU) {
            draw3d();
        }

        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.setProjectionMatrix(hud);
        sb.setProjectionMatrix(hud);
        ui.begin();
        if (state == S_MENU) {
            menuUi(w, h);
        } else if (state == S_PLAY) {
            playHud(w, h);
        } else if (state == S_DEAD) {
            tint(0.6f, 0f, 0f, 0.35f, w, h);
            centerText("YOU DIED", 5f, w, h * 0.78f);
            ui.add(B_RETRY, "RETRY", w * 0.5f - h * 0.5f, h * 0.3f, h * 0.45f, h * 0.15f, false);
            ui.add(B_MENU, "MENU", w * 0.5f + h * 0.05f, h * 0.3f, h * 0.45f, h * 0.15f, false);
        } else {
            tint(0f, 0.15f, 0.3f, 0.45f, w, h);
            centerText("PHASE 1 CLEARED", 5f, w, h * 0.8f);
            centerText("Time: " + ((int) (finalTime * 10f)) / 10f + " s", 3f, w, h * 0.6f);
            centerText("Phase 2 comes in a later update", 2f, w, h * 0.48f);
            ui.add(B_RETRY, "RETRY", w * 0.5f - h * 0.5f, h * 0.2f, h * 0.45f, h * 0.15f, false);
            ui.add(B_MENU, "MENU", w * 0.5f + h * 0.05f, h * 0.2f, h * 0.45f, h * 0.15f, false);
        }
        ui.draw(shapes, sb, font);
    }

    @Override
    public void resize(int width, int height) {
        cam.viewportWidth = width;
        cam.viewportHeight = height;
        cam.update();
        hud.setToOrtho2D(0f, 0f, width, height);
    }

    @Override
    public void dispose() {
        modelBatch.dispose();
        decalBatch.dispose();
        for (Model m : models) {
            m.dispose();
        }
        avatar.dispose();
        boss.dispose();
        attacks.dispose();
        shapes.dispose();
        sb.dispose();
        font.dispose();
    }
}
