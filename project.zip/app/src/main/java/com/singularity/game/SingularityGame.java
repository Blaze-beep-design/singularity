package com.singularity.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes.Usage;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;

public class SingularityGame extends ApplicationAdapter {
    static final float WALK_SPEED = 16f;
    static final float JUMP_POWER = 50f;
    static final float GRAVITY = 196.2f;
    static final float HALF = 150f;
    static final float CAM_DIST = 14f;
    static final float HEAD_HEIGHT = 4.5f;

    private PerspectiveCamera cam;
    private ModelBatch modelBatch;
    private Environment env;
    private final Array<ModelInstance> world = new Array<ModelInstance>();
    private final Array<Model> models = new Array<Model>();
    private ModelInstance body;
    private ModelInstance visor;

    private ShapeRenderer shapes;
    private SpriteBatch sb;
    private BitmapFont font;
    private final Matrix4 hud = new Matrix4();
    private TouchControls controls;

    private float px, py, pz, vy, heading;
    private boolean grounded;
    private float camYaw, camPitch;

    private Material mat(float r, float g, float b) {
        return new Material(ColorAttribute.createDiffuse(r, g, b, 1f));
    }

    private Model track(Model m) {
        models.add(m);
        return m;
    }

    private ModelInstance place(Model m, float x, float y, float z) {
        ModelInstance inst = new ModelInstance(m);
        inst.transform.setToTranslation(x, y, z);
        world.add(inst);
        return inst;
    }

    @Override
    public void create() {
        int w = Gdx.graphics.getWidth();
        int h = Gdx.graphics.getHeight();

        modelBatch = new ModelBatch();
        env = new Environment();
        env.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.45f, 0.45f, 0.55f, 1f));
        env.add(new DirectionalLight().set(0.9f, 0.85f, 1f, -0.5f, -1f, -0.3f));

        ModelBuilder mb = new ModelBuilder();
        long attr = Usage.Position | Usage.Normal;

        place(track(mb.createBox(HALF * 2f, 2f, HALF * 2f, mat(0.12f, 0.10f, 0.20f), attr)), 0f, -1f, 0f);

        Model lineX = track(mb.createBox(0.4f, 0.1f, HALF * 2f, mat(0.35f, 0.25f, 0.6f), attr));
        Model lineZ = track(mb.createBox(HALF * 2f, 0.1f, 0.4f, mat(0.35f, 0.25f, 0.6f), attr));
        for (int i = -6; i <= 6; i++) {
            float c = i * 25f;
            place(lineX, c, 0.05f, 0f);
            place(lineZ, 0f, 0.05f, c);
        }

        Model tower = track(mb.createBox(6f, 40f, 6f, mat(0.5f, 0.2f, 0.9f), attr));
        place(tower, HALF, 20f, HALF);
        place(tower, -HALF, 20f, HALF);
        place(tower, HALF, 20f, -HALF);
        place(tower, -HALF, 20f, -HALF);

        place(track(mb.createSphere(40f, 40f, 40f, 32, 16, mat(0.05f, 0.05f, 0.08f), attr)), 0f, 40f, 0f);

        body = new ModelInstance(track(mb.createBox(2f, 5f, 1f, mat(0.2f, 0.55f, 1f), attr)));
        visor = new ModelInstance(track(mb.createBox(1.2f, 0.8f, 0.3f, mat(1f, 1f, 1f), attr)));
        world.add(body);
        world.add(visor);

        cam = new PerspectiveCamera(67f, w, h);
        cam.near = 0.3f;
        cam.far = 1500f;

        shapes = new ShapeRenderer();
        sb = new SpriteBatch();
        font = new BitmapFont();
        font.getData().setScale(2f);
        hud.setToOrtho2D(0f, 0f, w, h);

        controls = new TouchControls();
        Gdx.input.setInputProcessor(controls);

        respawn();
    }

    private void respawn() {
        px = 0f;
        py = 0f;
        pz = 70f;
        vy = 0f;
        heading = 180f;
        grounded = true;
        camYaw = 180f;
        camPitch = 15f;
    }

    private void update(float dt) {
        camYaw += controls.consumeYaw();
        camPitch = MathUtils.clamp(camPitch + controls.consumePitch(), -30f, 80f);

        float fwdX = MathUtils.sinDeg(camYaw);
        float fwdZ = MathUtils.cosDeg(camYaw);
        float rightX = -fwdZ;
        float rightZ = fwdX;

        float sx = controls.moveX;
        float sy = controls.moveY;
        if (sx * sx + sy * sy < 0.01f) {
            sx = 0f;
            sy = 0f;
        }
        float dirX = fwdX * sy + rightX * sx;
        float dirZ = fwdZ * sy + rightZ * sx;
        float len = (float) Math.sqrt(dirX * dirX + dirZ * dirZ);
        if (len > 1f) {
            dirX /= len;
            dirZ /= len;
            len = 1f;
        }

        px += dirX * WALK_SPEED * dt;
        pz += dirZ * WALK_SPEED * dt;
        if (len > 0.05f) {
            float target = MathUtils.atan2(dirX, dirZ) * MathUtils.radiansToDegrees;
            heading = MathUtils.lerpAngleDeg(heading, target, Math.min(1f, 14f * dt));
        }

        if (grounded && controls.jumpHeld) {
            vy = JUMP_POWER;
            grounded = false;
        }
        vy -= GRAVITY * dt;
        py += vy * dt;
        boolean overPlatform = Math.abs(px) <= HALF && Math.abs(pz) <= HALF;
        if (overPlatform && py <= 0f && vy <= 0f) {
            py = 0f;
            vy = 0f;
            grounded = true;
        } else {
            grounded = false;
        }
        if (py < -60f) {
            respawn();
        }

        float dx = MathUtils.sinDeg(camYaw) * MathUtils.cosDeg(camPitch);
        float dy = -MathUtils.sinDeg(camPitch);
        float dz = MathUtils.cosDeg(camYaw) * MathUtils.cosDeg(camPitch);
        float tx = px;
        float ty = py + HEAD_HEIGHT;
        float tz = pz;
        cam.position.set(tx - dx * CAM_DIST, ty - dy * CAM_DIST, tz - dz * CAM_DIST);
        if (cam.position.y < 0.5f) {
            cam.position.y = 0.5f;
        }
        cam.up.set(0f, 1f, 0f);
        cam.lookAt(tx, ty, tz);
        cam.update();

        body.transform.idt().translate(px, py + 2.5f, pz).rotate(Vector3.Y, heading);
        visor.transform.set(body.transform).translate(0f, 1.2f, 0.55f);
    }

    @Override
    public void render() {
        float dt = Math.min(Gdx.graphics.getDeltaTime(), 0.05f);
        update(dt);

        Gdx.gl.glClearColor(0.04f, 0.02f, 0.07f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);
        modelBatch.begin(cam);
        modelBatch.render(world, env);
        modelBatch.end();

        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.setProjectionMatrix(hud);
        controls.draw(shapes);
        sb.setProjectionMatrix(hud);
        sb.begin();
        font.draw(sb, "SINGULARITY - movement test   FPS " + Gdx.graphics.getFramesPerSecond(),
                30f, Gdx.graphics.getHeight() - 30f);
        sb.end();
    }

    @Override
    public void resize(int width, int height) {
        cam.viewportWidth = width;
        cam.viewportHeight = height;
        cam.update();
        hud.setToOrtho2D(0f, 0f, width, height);
    }

    @Override
    public void dispose() {
        modelBatch.dispose();
        for (Model m : models) {
            m.dispose();
        }
        shapes.dispose();
        sb.dispose();
        font.dispose();
    }
}
