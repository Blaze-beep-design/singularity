package com.singularity.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public class SingularityGame extends ApplicationAdapter {
    private ShapeRenderer shapes;
    private SpriteBatch batch;
    private BitmapFont font;
    private float time;

    @Override
    public void create() {
        shapes = new ShapeRenderer();
        batch = new SpriteBatch();
        font = new BitmapFont();
        font.getData().setScale(3f);
    }

    @Override
    public void render() {
        time += Gdx.graphics.getDeltaTime();
        Gdx.gl.glClearColor(0.04f, 0.02f, 0.07f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        float w = Gdx.graphics.getWidth();
        float h = Gdx.graphics.getHeight();
        float r = Math.min(w, h) * 0.18f * (1f + 0.05f * (float) Math.sin(time * 2f));

        shapes.begin(ShapeRenderer.ShapeType.Line);
        shapes.setColor(0.35f, 0.2f, 0.85f, 1f);
        shapes.circle(w / 2f, h / 2f, r * 1.8f);
        shapes.setColor(0.7f, 0.3f, 1f, 1f);
        shapes.circle(w / 2f, h / 2f, r * 1.4f);
        shapes.end();

        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0f, 0f, 0f, 1f);
        shapes.circle(w / 2f, h / 2f, r);
        shapes.end();

        batch.begin();
        font.draw(batch, "SINGULARITY", w * 0.05f, h * 0.92f);
        font.draw(batch, "build pipeline works", w * 0.05f, h * 0.82f);
        batch.end();
    }

    @Override
    public void dispose() {
        shapes.dispose();
        batch.dispose();
        font.dispose();
    }
}
