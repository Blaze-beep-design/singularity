package com.singularity.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public class TouchControls extends InputAdapter {
    public static final float LOOK_SENS = 0.2f;
    public static final boolean INVERT_LOOK_Y = false;

    public float moveX;
    public float moveY;
    public boolean jumpHeld;

    private float lookYaw;
    private float lookPitch;

    private int stickPointer = -1;
    private int lookPointer = -1;
    private int jumpPointer = -1;
    private float baseX, baseY, knobX, knobY;
    private int lastLookX, lastLookY;

    private float stickRadius() {
        return Gdx.graphics.getHeight() * 0.14f;
    }

    private float jumpX() {
        return Gdx.graphics.getWidth() - Gdx.graphics.getHeight() * 0.2f;
    }

    private float jumpY() {
        return Gdx.graphics.getHeight() * 0.22f;
    }

    private float jumpR() {
        return Gdx.graphics.getHeight() * 0.1f;
    }

    public float consumeYaw() {
        float v = lookYaw;
        lookYaw = 0f;
        return v;
    }

    public float consumePitch() {
        float v = lookPitch;
        lookPitch = 0f;
        return v;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        float w = Gdx.graphics.getWidth();
        float h = Gdx.graphics.getHeight();
        float x = screenX;
        float y = h - screenY;
        float dx = x - jumpX();
        float dy = y - jumpY();
        float jr = jumpR() * 1.4f;
        if (jumpPointer == -1 && dx * dx + dy * dy <= jr * jr) {
            jumpPointer = pointer;
            jumpHeld = true;
            return true;
        }
        if (x < w * 0.5f) {
            if (stickPointer == -1) {
                stickPointer = pointer;
                baseX = x;
                baseY = y;
                knobX = x;
                knobY = y;
                moveX = 0f;
                moveY = 0f;
            }
        } else if (lookPointer == -1) {
            lookPointer = pointer;
            lastLookX = screenX;
            lastLookY = screenY;
        }
        return true;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        float h = Gdx.graphics.getHeight();
        if (pointer == stickPointer) {
            knobX = screenX;
            knobY = h - screenY;
            float dx = knobX - baseX;
            float dy = knobY - baseY;
            float r = stickRadius();
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len > r) {
                dx = dx / len * r;
                dy = dy / len * r;
                knobX = baseX + dx;
                knobY = baseY + dy;
            }
            moveX = dx / r;
            moveY = dy / r;
        } else if (pointer == lookPointer) {
            lookYaw -= (screenX - lastLookX) * LOOK_SENS;
            float dp = (screenY - lastLookY) * LOOK_SENS;
            lookPitch += INVERT_LOOK_Y ? -dp : dp;
            lastLookX = screenX;
            lastLookY = screenY;
        }
        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        if (pointer == stickPointer) {
            stickPointer = -1;
            moveX = 0f;
            moveY = 0f;
        } else if (pointer == lookPointer) {
            lookPointer = -1;
        } else if (pointer == jumpPointer) {
            jumpPointer = -1;
            jumpHeld = false;
        }
        return true;
    }

    public void draw(ShapeRenderer s) {
        s.begin(ShapeRenderer.ShapeType.Filled);
        if (stickPointer != -1) {
            s.setColor(1f, 1f, 1f, 0.12f);
            s.circle(baseX, baseY, stickRadius());
            s.setColor(1f, 1f, 1f, 0.35f);
            s.circle(knobX, knobY, stickRadius() * 0.4f);
        }
        s.setColor(1f, 1f, 1f, jumpHeld ? 0.45f : 0.2f);
        s.circle(jumpX(), jumpY(), jumpR());
        s.end();
    }
}
