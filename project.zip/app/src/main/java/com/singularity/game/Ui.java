package com.singularity.game;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public class Ui {
    private static final int MAX = 24;
    private final int[] ids = new int[MAX];
    private final String[] labels = new String[MAX];
    private final float[] bx = new float[MAX];
    private final float[] by = new float[MAX];
    private final float[] bw = new float[MAX];
    private final float[] bh = new float[MAX];
    private final boolean[] on = new boolean[MAX];
    private int n;
    private int pressed = -1;
    private final GlyphLayout layout = new GlyphLayout();

    public void begin() {
        n = 0;
    }

    public void add(int id, String label, float x, float y, float w, float h, boolean active) {
        if (n >= MAX) {
            return;
        }
        ids[n] = id;
        labels[n] = label;
        bx[n] = x;
        by[n] = y;
        bw[n] = w;
        bh[n] = h;
        on[n] = active;
        n++;
    }

    public boolean pressAt(float x, float y) {
        for (int i = n - 1; i >= 0; i--) {
            if (x >= bx[i] && x <= bx[i] + bw[i] && y >= by[i] && y <= by[i] + bh[i]) {
                pressed = ids[i];
                return true;
            }
        }
        return false;
    }

    public int consume() {
        int p = pressed;
        pressed = -1;
        return p;
    }

    public void draw(ShapeRenderer s, SpriteBatch sb, BitmapFont font) {
        s.begin(ShapeRenderer.ShapeType.Filled);
        for (int i = 0; i < n; i++) {
            if (on[i]) {
                s.setColor(0.2f, 0.85f, 0.4f, 0.55f);
            } else {
                s.setColor(1f, 1f, 1f, 0.18f);
            }
            s.rect(bx[i], by[i], bw[i], bh[i]);
        }
        s.end();
        sb.begin();
        for (int i = 0; i < n; i++) {
            layout.setText(font, labels[i]);
            font.draw(sb, labels[i], bx[i] + (bw[i] - layout.width) / 2f,
                    by[i] + (bh[i] + layout.height) / 2f);
        }
        sb.end();
    }
}
